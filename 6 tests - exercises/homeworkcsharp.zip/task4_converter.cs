// task 4: converter
// DIRECTORY: C:\Users\Sunrise GW\Desktop\SOU\SU\homeWork11042021
// FILENAME: task4_converter.cs

// INPUT
// Първи ред: число за преобразуване - реално число
// Втори ред: входна мерна единица - текст
// Трети ред: изходна мерна единица (за резултата) - текст

double number = double.Parse(Console.ReadLine());

string inputUnit = Console.ReadLine();
string outputUnit = Console.ReadLine();

